A = rand(10,12)
disp ('Get Window')
window = myFunction('window', A, 3, 4)

disp('Find Minimum')
minimim = myFunction('minwin', A)

disp('Find Minimum')
B = [1 2 3; 4 5 6; 7 0 9]
myFunction('minval', B)